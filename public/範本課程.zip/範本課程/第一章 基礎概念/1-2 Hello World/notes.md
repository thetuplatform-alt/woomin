# Hello World 入門 [00:00](#t=0)

本單元將帶你撰寫第一個程式。

## 建立檔案 [00:10](#t=10)

在專案根目錄建立 `index.js`，輸入以下內容：

```js
console.log('Hello World')
```

## 執行程式 [00:25](#t=25)

在終端機中輸入：

```bash
node index.js
```

你會看到終端機印出 `Hello World`，恭喜你完成了第一個程式！
